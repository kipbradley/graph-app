"""vt_graph_api.version.

This module provides version information.
"""


__version__ = '2.2.0'
__x_tool__ = 'Graph'
